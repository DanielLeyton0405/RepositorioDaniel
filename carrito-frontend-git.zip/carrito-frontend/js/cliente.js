function save() {
    // Construir el objeto data
    var data = {
      'id': $('#id').val(),
      'Nombre': $('#Nombre').val(),
      'Correos': $('#Correos').val(),
      'Telefonos': $('#Telefonos').val(),
      'Direccion': $('#Direccion').val(),
      
      
    };
  
    var jsonData = JSON.stringify(data);
    $.ajax({
      url: 'http://localhost:9000/v1/api/producto',
      method: 'POST',
      dataType: 'json',
      contentType: 'application/json',
      data: jsonData,
      success: function (data) {
        alert("Registro agregado con éxito");
        loadData();
        clearData();
      },
      error: function (error) {
        console.error('Error en la solicitud:', error);
      }
    });
  }
  
  function update() {
    // Construir el objeto data
    var data = {
        'id': $('#id').val(),
        'Nombre': $('#Nombre').val(),
        'Correos': $('#Correos').val(),
        'Telefonos': $('#Telefonos').val(),
        'Direccion': $('#Direccion').val(),
    };
    var id = $("#id").val();
    var jsonData = JSON.stringify(data);
    $.ajax({
      url: 'http://localhost:9000/v1/api/producto/' +id,
      data: jsonData,
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      }
    }).done(function (result) {
      alert("Registro actualizado con éxito");
      loadData();
      clearData();
  
      //actualzar boton
      var btnAgregar = $('button[name="btnAgregar"]');
      btnAgregar.text('Agregar');
      btnAgregar.attr('onclick', 'save()');
    })
  }
  
  function loadData() {
    $.ajax({
      url: 'http://localhost:9000/v1/api/producto',
      method: 'GET',
      dataType: 'json',
      success: function (data) {
        var html = '';
  
        data.forEach(function (item) {
          // Construir el HTML para cada objeto
          html += `<tr>
                  <td>`+ item.id + `</td>
                  <td>`+ item.Nombre + `</td>
                  <td>`+ item.Correos + `</td>
                  <td>`+ item.Telefonos + `</td>
                  <td>`+ item.Direccion + `</td>
                  <th><img src="../asset/icon/pencil-square.svg" alt="" onclick="findById(`+ item.id + `)"></th>
                  <th><img src="../asset/icon/trash3.svg" alt="" onclick="deleteById(`+ item.id + `)"></th>
              </tr>`;
        });
  
        $('#resultData').html(html);
      },
      error: function (error) {
        // Función que se ejecuta si hay un error en la solicitud
        console.error('Error en la solicitud:', error);
      }
    });
  }
  
  function findById(id) {
    $.ajax({
      url: 'http://localhost:9000/v1/api/producto/' + id,
      method: 'GET',
      dataType: 'json',
      success: function (data) {
        $('#id').val(data.id);
        $('#Nombre').val(data.Nombre);
        $('#Correos').val(data.Correos);
        $('#Telefonos').val(data.Telefonos);
        $('#Direccion').val(data.Direccion);
       
  
        //Cambiar boton.
        var btnAgregar = $('button[name="btnAgregar"]');
        btnAgregar.text('Actualizar');
        btnAgregar.attr('onclick', 'update(' + data.id + ')');
          // Agregar enlaces o botones de acciones
      var accionesHtml = '<a href="#" onclick="deleteById(' + data.id + ')">Eliminar</a>';
      accionesHtml += ' | ';
      accionesHtml += '<a href="#" onclick="clearData()">Cancelar</a>';
      $('#acciones').html(accionesHtml);


      },
      error: function (error) {
        // Función que se ejecuta si hay un error en la solicitud
        console.error('Error en la solicitud:', error);
      }
    });
  }
  
  function deleteById(id) {
    $.ajax({
      url: 'http://localhost:9000/v1/api/producto/' + id,
      method: "delete",
      headers: {
        "Content-Type": "application/json"
      }
    }).done(function (result) {
      alert("Registro eliminado con éxito");
      loadData();
      clearData();
    })
  }
  
  function clearData() {
    $('#id').val('');
    $('#Nombre').val('');
    $('#Correos').val('');
    $('#Telefonos').val('');
    $('#Direccion').val('');
    
  }
  
  
  
  